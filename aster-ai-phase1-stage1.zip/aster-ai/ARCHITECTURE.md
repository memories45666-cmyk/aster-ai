# ASTER AI — System Architecture

*One AI. Every capability.*

ASTER is not a foundation model. It's an orchestration layer around existing
LLM APIs (Anthropic, OpenAI, Gemini, and future/local models) plus retrieval,
memory, tools, and agents — designed so a user experiences one coherent
assistant even though multiple models and subsystems cooperate behind the
scenes.

---

## A. Architecture overview

```
 USER
   │
 ASTER CLIENT (Next.js / React)
   │  fetch, streamed NDJSON
 API ROUTES (/api/chat, /api/files, /api/memory, ...)
   │
 REQUEST ORCHESTRATOR
   │
   ├─ INTENT CLASSIFICATION  ── what is the user asking? which mode?
   ├─ MEMORY RETRIEVAL       ── relevant user/project memory
   ├─ CONTEXT / RAG RETRIEVAL── relevant document chunks
   ├─ MODEL ROUTER           ── which provider + model for this task
   ├─ TOOLS / AGENTS         ── calculator, search, code exec, file reader
   │
 RESPONSE SYNTHESIZER  ── merge tool/agent output into one answer
   │
 SAFETY + QUALITY CHECK
   │
 USER RESPONSE (streamed)
```

Every arrow is a typed interface, not a direct dependency. The API route
never imports `@anthropic-ai/sdk`; it calls `router.route(task)` and gets
back something that satisfies `AIProvider`. The UI never knows which
provider answered. This is what lets Phase 5+ (agents) and Phase 6
(multimodal) get added without rewriting Phase 1.

**Status:** stage 1 of Phase 1 is implemented in this codebase — client →
API route → model router → Anthropic provider → streamed response. Intent
classification, memory retrieval, and RAG retrieval are designed below and
stubbed as the next stages.

---

## B. Technology stack

Chosen for a single developer who needs to ship, not for resume-driven
architecture:

| Layer | Choice | Why |
|---|---|---|
| Frontend | Next.js 14 (App Router) + React + TypeScript | One deploy target for UI and API routes; streaming works natively with the Web Streams API used in `route.ts` |
| Styling | Tailwind CSS | Fast iteration, matches the design-token approach in `globals.css` |
| Backend | Next.js Route Handlers | No separate backend service to deploy/scale for an MVP; can be split out later if load requires it |
| Database | PostgreSQL | Relational integrity for users/conversations/messages; `pgvector` extension covers embeddings later without a separate vector DB |
| ORM | Prisma | Type-safe schema, migrations, works cleanly with the table design in section C |
| Object storage | S3-compatible (AWS S3, Cloudflare R2, or Supabase Storage) | Files/attachments never belong in Postgres rows |
| Auth | NextAuth.js (Auth.js) | Handles session/JWT plumbing so Phase 1 stage 2 isn't reinventing auth |
| AI providers | Anthropic + OpenAI SDKs behind the `AIProvider` interface | See section D |
| Deployment | Vercel (app) + managed Postgres (Neon/Supabase/RDS) | Minimal ops for a solo/small team |

This is a default, not a mandate — the provider and tool abstractions mean
swapping Prisma for Drizzle, or Vercel for Railway, doesn't touch business
logic.

---

## C. Database schema

```
users
  id UUID PK
  email TEXT UNIQUE NOT NULL
  name TEXT
  created_at TIMESTAMPTZ

conversations
  id UUID PK
  user_id UUID FK -> users.id
  project_id UUID FK -> projects.id NULL
  title TEXT
  mode TEXT  -- chat | research | study | coding | document | agent
  created_at TIMESTAMPTZ
  updated_at TIMESTAMPTZ
  INDEX (user_id, updated_at DESC)

messages
  id UUID PK
  conversation_id UUID FK -> conversations.id
  role TEXT  -- user | assistant | system
  content JSONB  -- MessageContent[]
  model TEXT NULL
  provider TEXT NULL
  input_tokens INT NULL
  output_tokens INT NULL
  created_at TIMESTAMPTZ
  INDEX (conversation_id, created_at)

attachments
  id UUID PK
  message_id UUID FK -> messages.id
  file_id UUID FK -> documents.id
  kind TEXT  -- image | file | audio

documents
  id UUID PK
  user_id UUID FK -> users.id
  project_id UUID FK -> projects.id NULL
  file_name TEXT
  mime_type TEXT
  storage_key TEXT  -- object storage path, not the file itself
  status TEXT  -- pending | processed | failed
  created_at TIMESTAMPTZ

document_chunks
  id UUID PK
  document_id UUID FK -> documents.id
  chunk_index INT
  page_number INT NULL
  content TEXT
  embedding VECTOR(1536)  -- pgvector
  created_at TIMESTAMPTZ
  INDEX ivfflat (embedding)
  INDEX (document_id, chunk_index)

memories
  id UUID PK
  user_id UUID FK -> users.id
  project_id UUID FK -> projects.id NULL
  scope TEXT  -- user | project | task
  content TEXT
  source_conversation_id UUID NULL
  created_at TIMESTAMPTZ
  INDEX (user_id, scope)

projects
  id UUID PK
  user_id UUID FK -> users.id
  name TEXT
  instructions TEXT NULL
  created_at TIMESTAMPTZ

tasks
  id UUID PK
  user_id UUID FK -> users.id
  conversation_id UUID FK -> conversations.id NULL
  status TEXT  -- pending | running | completed | failed
  goal TEXT
  result JSONB NULL
  created_at TIMESTAMPTZ
  updated_at TIMESTAMPTZ

tool_calls
  id UUID PK
  message_id UUID FK -> messages.id
  tool_name TEXT
  input JSONB
  output JSONB NULL
  status TEXT  -- success | error
  latency_ms INT
  created_at TIMESTAMPTZ

model_requests
  id UUID PK
  message_id UUID FK -> messages.id NULL
  provider TEXT
  model TEXT
  input_tokens INT
  output_tokens INT
  latency_ms INT
  estimated_cost_usd NUMERIC(10,6)
  created_at TIMESTAMPTZ

sources
  id UUID PK
  message_id UUID FK -> messages.id
  url TEXT
  title TEXT
  snippet TEXT
  published_at TIMESTAMPTZ NULL

usage
  id UUID PK
  user_id UUID FK -> users.id
  period DATE
  total_input_tokens BIGINT
  total_output_tokens BIGINT
  estimated_cost_usd NUMERIC(10,2)

settings
  user_id UUID PK FK -> users.id
  preferred_model TEXT NULL
  memory_enabled BOOLEAN DEFAULT true
  web_search_enabled BOOLEAN DEFAULT true
  theme TEXT DEFAULT 'system'
```

`users → conversations → messages → attachments` and `documents →
document_chunks` are the two backbone chains; everything else (memories,
tasks, tool_calls, model_requests, sources, usage) hangs off `users` and
`messages` for auditability without forcing every query to join through
conversations.

---

## D. AI provider abstraction

Implemented in `src/lib/ai/providers/`. The interface:

```ts
interface AIProvider {
  readonly name: string;
  generateText(options: GenerateTextOptions): Promise<GenerateTextResult>;
  streamText(options: GenerateTextOptions): AsyncGenerator<{ text: string }, GenerateTextResult>;
  generateStructuredOutput<T>(options: StructuredOutputOptions<T>): Promise<T>;
  analyzeImage?(imageUrl: string, prompt: string, model: string): Promise<string>;
  createEmbedding?(text: string, model: string): Promise<number[]>;
}
```

`AnthropicProvider` and `OpenAIProvider` both implement it today. A Gemini
or local-model provider is one new file; nothing in the router, API routes,
or UI changes. Optional methods (`analyzeImage`, `createEmbedding`) are
capability flags — the router checks for their presence before routing a
vision or embedding task to a given provider.

---

## E. Model router

Implemented in `src/lib/ai/router.ts`. Callers never name a model — they
name a `TaskType` (`chat`, `reasoning`, `vision`, `coding`,
`long_context`, `summarization`), and the router resolves that to a
provider + model id, reading `PRIMARY_MODEL` / `FAST_MODEL` /
`REASONING_MODEL` / `VISION_MODEL` from the environment so the mapping is
a config change, not a code change.

Routing logic (current + planned):

- Simple question → fast model (`FAST_MODEL`)
- Complex reasoning / multi-step planning → reasoning model
- Huge document in context → long-context-capable model
- Image in the request → vision model
- Coding-heavy request → coding-capable model (currently same as primary;
  splits out once a coding-specialized model is worth the routing branch)
- Everything else → primary model

Stage 1 ships everything routed through Anthropic because that's the only
key wired by default; the `switch` is already task-shaped so widening it to
multiple providers per task is additive.

---

## F. Tool architecture

```ts
interface Tool {
  name: string;
  description: string;
  inputSchema: object;   // JSON schema, validated before execute() runs
  execute(input: unknown): Promise<unknown>;
}
```

A `ToolRegistry` holds `Map<string, Tool>`. The orchestrator asks the model
which tool (if any) a request needs — via native tool-use where the
provider supports it — validates the model's proposed input against
`inputSchema`, executes, and feeds the structured result back for the model
to synthesize into a final answer. Adding a tool means registering one
object; the orchestrator loop doesn't change.

Planned Phase 3 tools: calculator, web search, file reader, code
interpreter (sandboxed — see section I), image analyzer, structured-data
(JSON/CSV) tool, date/time tool.

---

## G. RAG architecture

```
upload → text extraction → cleaning → chunking → metadata → embedding
  → pgvector storage → semantic retrieval → rerank/filter → LLM context
```

- **Chunking:** ~500–800 tokens with ~15% overlap; PDFs keep page numbers
  in metadata (`document_chunks.page_number`) specifically so answers can
  cite "page 12" honestly.
- **Retrieval:** cosine similarity via `pgvector` `ivfflat` index, top-k
  (default 8), then a lightweight rerank pass before the chunks reach the
  model.
- **Citations:** the synthesizer is instructed to cite only chunks actually
  present in its context window, by `document_id` + `page_number`. If no
  retrieved chunk supports a claim, the model is instructed to say so
  rather than cite anyway — never fabricate a citation.

---

## H. Memory architecture

Five scopes, deliberately not "save everything":

| Scope | Lifetime | Example |
|---|---|---|
| Conversation | current chat only | "earlier you said X" |
| User | across all conversations | stated preferences, recurring facts |
| Project | scoped to one project | "this project's stack is Next.js + Postgres" |
| Task | one long-running task | intermediate state of a research job |
| Knowledge | derived from uploaded docs | handled by RAG, not the memory table |

Write policy before anything lands in `memories`:

```
should this be remembered?
  → is it useful in a future conversation? (not just this turn)
  → is it appropriate to persist? (not sensitive without consent)
  → does the user need to confirm, or is this an unambiguous stated fact?
```

Users get full CRUD over their own memory (`/api/memory`) plus a
memory-disabled setting (`settings.memory_enabled`) that, when off, skips
the write step entirely rather than writing-then-hiding.

---

## I. Security architecture

- **Auth/session:** NextAuth.js, HTTP-only cookies, no tokens in
  `localStorage`.
- **Secrets:** API keys live in server-only environment variables, read
  only inside `src/lib/ai/providers/*` and never serialized to a client
  component or response body.
- **Trust hierarchy** (for prompt-injection defense): system instructions >
  application instructions > authenticated user input > external content
  (web pages, documents, tool output). External content is always wrapped
  and passed to the model labeled as *data*, never concatenated into the
  system or developer prompt as if it were an instruction.
- **Code execution:** the "Code Interpreter" tool runs in an isolated,
  resource-capped sandbox (e.g. a locked-down container or a service like
  E2B/Firecracker microVMs) — never in the same process or host as the API
  server.
- **Input validation:** every API route validates its body shape (zod
  schemas) before touching the database or calling a provider.
- **File handling:** MIME-type allowlist, size caps, virus/malware scanning
  hook before a file is marked `processed` and becomes retrievable.
- **Standard web hardening:** parameterized queries only (Prisma handles
  this), output encoding against XSS, CSRF tokens on state-changing
  non-API-key requests, rate limiting per user/IP on `/api/chat` and
  `/api/files/upload`.
- **Audit logs:** `tool_calls` and `model_requests` tables double as an
  audit trail — who called what tool/model, when, with what latency —
  without logging prompt content by default.

---

## J. MVP implementation plan

**Phase 1 — MVP** (this repo)
1. ✅ Provider abstraction + model router + streaming chat API + chat UI
   *(current stage — no auth, no persistence yet)*
2. Auth (NextAuth.js) + Postgres + Prisma schema for
   users/conversations/messages; persist real chat history
3. Basic settings (model preference, theme, memory toggle)

**Phase 2 — Knowledge:** file upload → object storage → text
extraction/chunking → embeddings → `document_chunks` → citations in chat.

**Phase 3 — Tools:** tool registry, calculator + web search first (highest
value, lowest risk), then sandboxed code execution.

**Phase 4 — Memory:** `memories` table + write policy + `/api/memory` CRUD
+ a memory management UI.

**Phase 5 — Agents:** research/coding/document workers behind a
controlled orchestrator; `tasks` table for long-running jobs with visible
status.

**Phase 6 — Multimodal:** image input via `analyzeImage`, voice
(speech-to-text in, text-to-speech out, swappable provider).

**Phase 7 — Production hardening:** rate limiting, monitoring, cost
dashboards from `model_requests`/`usage`, automated test suite (unit,
integration, plus AI-specific: hallucination checks, citation accuracy,
prompt-injection tests, tool-selection accuracy).

Each stage follows the same loop: explain what's being built → create the
files → implement → check for obvious bugs → explain how to test it →
move on. No stage rewrites a previous stage's working code without a
stated reason.
