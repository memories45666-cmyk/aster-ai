# ASTER AI — Phase 1 MVP (stage 1)

One AI. Every capability. This is the first working slice: a provider-agnostic
AI abstraction, a task-based model router, a streaming chat API, and a chat UI.

## What's here

```
src/
  types/chat.ts              Shared message schema (multimodal-ready)
  lib/ai/providers/types.ts  The AIProvider interface every provider implements
  lib/ai/providers/anthropic.ts
  lib/ai/providers/openai.ts
  lib/ai/router.ts           Task type -> provider + model decision
  app/api/chat/route.ts      POST /api/chat — streams NDJSON token events
  app/page.tsx               Chat UI (sidebar shell + message stream + composer)
  components/                ChatMessages, MessageBubble, ChatInput
```

**Why it's built this way:** nothing above `lib/ai/router.ts` ever imports
`@anthropic-ai/sdk` or `openai` directly, and nothing outside
`lib/ai/providers/` knows a provider's request/response shape. Adding Gemini
later, or moving `coding` tasks to a different model, is a change inside
`lib/ai/`, not a change to the API route or the UI.

## Setup

```bash
npm install
cp .env.example .env.local
# put your key in .env.local
npm run dev
```

You need ONE of these in `.env.local` — the router auto-detects which:

```
ANTHROPIC_API_KEY=sk-ant-...
# or
OPENROUTER_API_KEY=sk-or-v1-...
# or
OPENAI_API_KEY=sk-...
```

If you're using OpenRouter, also set model ids in OpenRouter's format (see
the comments in `.env.example`) — OpenRouter's own model names, like
`anthropic/claude-sonnet-4.5`, not the provider's native ones.

Open http://localhost:3000 **on the same machine that's running `npm run
dev`**. This is what "local" means here: the server only listens on that
machine. It will not be reachable from your phone unless you deploy it
somewhere (see "Running this from a phone" below).

## Testing this stage

1. `npm run typecheck` — should be clean.
2. Start the dev server, send a message, confirm tokens stream in (not a
   single delayed blob).
3. Kill your network mid-stream or set a bad API key — confirm you get the
   inline error bar under the chat, not a crash or a stuck spinner.
4. Send two messages back to back — confirm the second request includes the
   first exchange (`nextMessages` in `page.tsx`), i.e. context is preserved
   within the tab.

## Running this from a phone

`npm run dev` starts a server on `localhost` — that's only reachable from
the same device. To open ASTER from a phone browser, pick one:

1. **Deploy it (real public URL, recommended):** push this folder to a
   GitHub repo, then import it at vercel.com (free tier). Add your API key
   under Vercel's Environment Variables. You get a real `https://...` link
   that opens on any device, including your phone.
2. **Run it in-browser, no install (good for trying it out from the
   phone itself):** stackblitz.com or codesandbox.io can run a Next.js
   project entirely in the browser via WebContainers. Create a Next.js
   project there and paste these files in, then add your key in their env
   settings.
3. **A computer on the same Wi-Fi as your phone:** run `npm run dev --
   -H 0.0.0.0`, then on your phone open `http://<that computer's local
   IP>:3000`. Only works while both devices are on the same network and
   that computer is running the server.

## What's intentionally NOT here yet

Per the phased plan: no auth, no persisted conversation history (a refresh
clears the chat — state lives in `useState` in `page.tsx`), no memory, no
RAG, no tools, no search. Those are Phase 1 stage 2 onward. `DATABASE_URL` in
`.env.example` is a placeholder for that next stage, not wired to anything
yet.

## Design tokens

Color/type tokens live in `src/app/globals.css` (`:root` and `.dark`). Accent
is a violet (`#6e56cf` light / `#9b8afb` dark) — deliberately distinct from
both the generic "warm terracotta on cream" and "neon on near-black" AI-app
defaults. Swap those CSS variables to reskin without touching components.
