// Multimodal-ready content schema. Phase 1 only sends "text", but every
// downstream consumer (providers, API route, UI) already speaks this type
// so image/file/audio support (Phase 6) is additive, not a rewrite.
export type MessageContent =
  | { type: "text"; text: string }
  | { type: "image"; url: string }
  | { type: "file"; fileId: string; fileName?: string }
  | { type: "audio"; fileId: string };

export type ChatRole = "user" | "assistant" | "system";

export interface ChatMessage {
  id: string;
  role: ChatRole;
  content: MessageContent[];
  createdAt: string; // ISO 8601
}

// What the client sends to POST /api/chat
export interface ChatRequest {
  conversationId?: string;
  messages: ChatMessage[];
  mode?: "chat" | "research" | "study" | "coding" | "document" | "agent";
}

// A single streamed chunk. The route emits these as newline-delimited JSON;
// the client reassembles them into a ChatMessage as they arrive.
export type ChatStreamEvent =
  | { type: "token"; text: string }
  | { type: "done"; usage?: { inputTokens: number; outputTokens: number } }
  | { type: "error"; message: string };
