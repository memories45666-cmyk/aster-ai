"use client";

import { useState } from "react";
import { ChatMessages } from "@/components/ChatMessages";
import { ChatInput } from "@/components/ChatInput";
import type { ChatMessage, ChatStreamEvent } from "@/types/chat";

const NAV_ITEMS = ["Conversations", "Projects", "Files", "Research", "Settings"];

function newId() {
  return crypto.randomUUID();
}

export default function Home() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [errorText, setErrorText] = useState<string | null>(null);

  async function handleSend(text: string) {
    setErrorText(null);

    const userMessage: ChatMessage = {
      id: newId(),
      role: "user",
      content: [{ type: "text", text }],
      createdAt: new Date().toISOString(),
    };
    const assistantId = newId();
    const assistantMessage: ChatMessage = {
      id: assistantId,
      role: "assistant",
      content: [{ type: "text", text: "" }],
      createdAt: new Date().toISOString(),
    };

    const nextMessages = [...messages, userMessage];
    setMessages([...nextMessages, assistantMessage]);
    setIsStreaming(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: nextMessages, mode: "chat" }),
      });

      if (!res.ok || !res.body) {
        throw new Error(`Request failed (${res.status})`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let accumulated = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";

        for (const line of lines) {
          if (!line.trim()) continue;
          const event: ChatStreamEvent = JSON.parse(line);

          if (event.type === "token") {
            accumulated += event.text;
            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantId
                  ? { ...m, content: [{ type: "text", text: accumulated }] }
                  : m
              )
            );
          } else if (event.type === "error") {
            setErrorText(event.message);
          }
        }
      }
    } catch (err) {
      setErrorText(
        err instanceof Error ? err.message : "Something went wrong talking to ASTER."
      );
    } finally {
      setIsStreaming(false);
    }
  }

  return (
    <div className="flex h-screen bg-background text-foreground">
      <aside className="hidden w-60 shrink-0 flex-col border-r border-border p-3 md:flex">
        <div className="mb-4 flex items-center gap-2 px-2 py-1.5">
          <div className="h-6 w-6 rounded-full bg-accent" />
          <span className="text-[15px] font-semibold">ASTER</span>
        </div>
        <button className="mb-4 rounded-md border border-border px-3 py-2 text-left text-sm hover:bg-surface">
          New chat
        </button>
        <nav className="flex flex-col gap-0.5">
          {NAV_ITEMS.map((item) => (
            <button
              key={item}
              className="rounded-md px-3 py-2 text-left text-sm text-muted hover:bg-surface hover:text-foreground"
            >
              {item}
            </button>
          ))}
        </nav>
      </aside>

      <main className="flex flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-border px-4 py-3 md:hidden">
          <span className="text-[15px] font-semibold">ASTER</span>
        </header>

        <div className="flex-1 overflow-y-auto">
          <ChatMessages messages={messages} />
        </div>

        {errorText && (
          <div className="mx-auto w-full max-w-2xl px-4 pb-2">
            <p className="rounded-md border border-border bg-surface px-3 py-2 text-sm text-muted">
              {errorText}
            </p>
          </div>
        )}

        <ChatInput onSend={handleSend} disabled={isStreaming} />
      </main>
    </div>
  );
}
