import { NextRequest } from "next/server";
import { route } from "@/lib/ai/router";
import type { ChatRequest, ChatStreamEvent } from "@/types/chat";

export const runtime = "nodejs";

const SYSTEM_PROMPT = `You are ASTER, a helpful and direct AI assistant. Be clear and concise. Use markdown, code blocks, and tables where they help. If you're not sure about something, say so instead of guessing.`;

function encode(event: ChatStreamEvent): Uint8Array {
  return new TextEncoder().encode(JSON.stringify(event) + "\n");
}

export async function POST(req: NextRequest) {
  let body: ChatRequest;
  try {
    body = await req.json();
  } catch {
    return new Response("Invalid JSON body", { status: 400 });
  }

  if (!body?.messages?.length) {
    return new Response("messages is required", { status: 400 });
  }

  // Phase 1: every request routes as plain "chat". Phase 3+ intent
  // classification will pick "coding" / "reasoning" / etc. here based on
  // body.mode and the content of the latest message.
  const { provider, model } = route("chat");

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        const generator = provider.streamText({
          model,
          messages: body.messages,
          system: SYSTEM_PROMPT,
          maxTokens: 2048,
        });

        let result;
        while (true) {
          const { value, done } = await generator.next();
          if (done) {
            result = value;
            break;
          }
          controller.enqueue(encode({ type: "token", text: value.text }));
        }

        controller.enqueue(
          encode({
            type: "done",
            usage: result?.usage,
          })
        );
      } catch (err) {
        const message =
          err instanceof Error ? err.message : "Unknown error generating a response.";
        controller.enqueue(encode({ type: "error", message }));
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "application/x-ndjson; charset=utf-8",
      "Cache-Control": "no-cache",
    },
  });
}
