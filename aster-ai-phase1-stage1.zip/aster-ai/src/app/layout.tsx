import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ASTER — One AI. Every capability.",
  description: "ASTER is an AI assistant that brings chat, research, and tools together.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
