import type { ChatMessage } from "@/types/chat";

function textOf(message: ChatMessage): string {
  return message.content
    .filter((c) => c.type === "text")
    .map((c) => (c as { type: "text"; text: string }).text)
    .join("\n\n");
}

export function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";
  const text = textOf(message);

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={
          isUser
            ? "max-w-[75%] rounded-lg bg-accent px-4 py-2.5 text-accent-foreground"
            : "max-w-[75%] rounded-lg border border-border bg-surface px-4 py-2.5"
        }
      >
        <p className="whitespace-pre-wrap text-[15px] leading-relaxed">
          {text || (isUser ? "" : "…")}
        </p>
      </div>
    </div>
  );
}
