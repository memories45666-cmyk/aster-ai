import { AnthropicProvider } from "./providers/anthropic";
import { OpenAIProvider } from "./providers/openai";
import { OpenRouterProvider } from "./providers/openrouter";
import type { AIProvider } from "./providers/types";

export type TaskType =
  | "chat"
  | "reasoning"
  | "long_context"
  | "vision"
  | "coding"
  | "summarization";

interface RouteDecision {
  provider: AIProvider;
  model: string;
}

// Lazily constructed so a missing API key only breaks the providers that
// actually need it, not the whole app (e.g. dev with only ANTHROPIC_API_KEY set).
let anthropic: AnthropicProvider | null = null;
let openai: OpenAIProvider | null = null;
let openrouter: OpenRouterProvider | null = null;

function getAnthropic(): AnthropicProvider {
  if (!anthropic) {
    const key = process.env.ANTHROPIC_API_KEY;
    if (!key) throw new Error("ANTHROPIC_API_KEY is not set");
    anthropic = new AnthropicProvider(key);
  }
  return anthropic;
}

function getOpenAI(): OpenAIProvider {
  if (!openai) {
    const key = process.env.OPENAI_API_KEY;
    if (!key) throw new Error("OPENAI_API_KEY is not set");
    openai = new OpenAIProvider(key);
  }
  return openai;
}

function getOpenRouter(): OpenRouterProvider {
  if (!openrouter) {
    const key = process.env.OPENROUTER_API_KEY;
    if (!key) throw new Error("OPENROUTER_API_KEY is not set");
    openrouter = new OpenRouterProvider(key);
  }
  return openrouter;
}

// Picks whichever key is actually configured, in this preference order, so
// the app runs out of the box with just one provider's key set — no code
// change needed to go from "only have an OpenRouter key" to "added an
// Anthropic key later".
function getDefaultProvider(): { provider: AIProvider; fallbackModel: string } {
  if (process.env.ANTHROPIC_API_KEY) {
    return { provider: getAnthropic(), fallbackModel: "claude-sonnet-4-6" };
  }
  if (process.env.OPENROUTER_API_KEY) {
    return {
      provider: getOpenRouter(),
      fallbackModel: "anthropic/claude-sonnet-4.5",
    };
  }
  if (process.env.OPENAI_API_KEY) {
    return { provider: getOpenAI(), fallbackModel: "gpt-4o" };
  }
  throw new Error(
    "No provider API key set. Add ANTHROPIC_API_KEY, OPENROUTER_API_KEY, or OPENAI_API_KEY to .env.local"
  );
}

/**
 * Single decision point for "which model answers this". Everything else in
 * the app asks for a TaskType, never a model id or provider name — so
 * changing PRIMARY_MODEL, adding Gemini, or moving reasoning tasks to a
 * different provider is a one-file change.
 *
 * Phase 1 routes everything to Anthropic (env-configured models) since it's
 * the only provider with a real API key by default. The switch is already
 * task-shaped so Phase 2+ can send `coding` to a stronger coding model,
 * `vision` to a vision-capable model, etc. without touching call sites.
 */
export function route(task: TaskType): RouteDecision {
  const { provider, fallbackModel } = getDefaultProvider();

  const envModel =
    task === "reasoning"
      ? process.env.REASONING_MODEL
      : task === "vision"
      ? process.env.VISION_MODEL
      : task === "summarization"
      ? process.env.FAST_MODEL
      : process.env.PRIMARY_MODEL;

  // envModel lets you override per task without touching code; fallbackModel
  // is whatever's sane for the provider that's actually configured, so the
  // app still runs with zero PRIMARY_MODEL/FAST_MODEL/... vars set.
  return { provider, model: envModel ?? fallbackModel };
}

// Exported for Phase 3+ (letting a user pick a provider explicitly in
// Settings), unused by the default route() above so nothing breaks without
// every key set.
export function routeToProvider(providerName: "anthropic" | "openai" | "openrouter") {
  if (providerName === "openai") return getOpenAI();
  if (providerName === "openrouter") return getOpenRouter();
  return getAnthropic();
}
