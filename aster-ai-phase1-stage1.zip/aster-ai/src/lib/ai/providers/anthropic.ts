import Anthropic from "@anthropic-ai/sdk";
import type { ChatMessage } from "@/types/chat";
import type {
  AIProvider,
  GenerateTextOptions,
  GenerateTextResult,
  StructuredOutputOptions,
} from "./types";

function toAnthropicMessages(messages: ChatMessage[]) {
  return messages
    .filter((m) => m.role !== "system")
    .map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content
        .filter((c) => c.type === "text")
        .map((c) => (c as { type: "text"; text: string }).text)
        .join("\n\n"),
    }));
}

export class AnthropicProvider implements AIProvider {
  readonly name = "anthropic";
  private client: Anthropic;

  constructor(apiKey: string) {
    // Server-side only. Never import this file from client components —
    // the API key would end up in the browser bundle.
    this.client = new Anthropic({ apiKey });
  }

  async generateText(opts: GenerateTextOptions): Promise<GenerateTextResult> {
    const res = await this.client.messages.create({
      model: opts.model,
      max_tokens: opts.maxTokens ?? 1024,
      temperature: opts.temperature,
      system: opts.system,
      messages: toAnthropicMessages(opts.messages),
    });

    const text = res.content
      .filter((b) => b.type === "text")
      .map((b) => (b as { type: "text"; text: string }).text)
      .join("");

    return {
      text,
      usage: {
        inputTokens: res.usage.input_tokens,
        outputTokens: res.usage.output_tokens,
      },
      model: opts.model,
      provider: this.name,
    };
  }

  async *streamText(
    opts: GenerateTextOptions
  ): AsyncGenerator<{ text: string }, GenerateTextResult, unknown> {
    const stream = this.client.messages.stream({
      model: opts.model,
      max_tokens: opts.maxTokens ?? 1024,
      temperature: opts.temperature,
      system: opts.system,
      messages: toAnthropicMessages(opts.messages),
    });

    for await (const event of stream) {
      if (
        event.type === "content_block_delta" &&
        event.delta.type === "text_delta"
      ) {
        yield { text: event.delta.text };
      }
    }

    const final = await stream.finalMessage();
    const text = final.content
      .filter((b) => b.type === "text")
      .map((b) => (b as { type: "text"; text: string }).text)
      .join("");

    return {
      text,
      usage: {
        inputTokens: final.usage.input_tokens,
        outputTokens: final.usage.output_tokens,
      },
      model: opts.model,
      provider: this.name,
    };
  }

  async generateStructuredOutput<T>(
    opts: StructuredOutputOptions<T>
  ): Promise<T> {
    const system = [
      opts.system,
      `Respond with ONLY valid JSON matching this shape, no markdown fences, no preamble: ${opts.schemaDescription}`,
    ]
      .filter(Boolean)
      .join("\n\n");

    const result = await this.generateText({ ...opts, system });
    const cleaned = result.text.replace(/```json|```/g, "").trim();
    return opts.parse(cleaned);
  }
}
