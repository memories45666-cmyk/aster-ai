import type { ChatMessage } from "@/types/chat";

export interface GenerateTextOptions {
  model: string;
  messages: ChatMessage[];
  system?: string;
  maxTokens?: number;
  temperature?: number;
}

export interface GenerateTextResult {
  text: string;
  usage: { inputTokens: number; outputTokens: number };
  model: string;
  provider: string;
}

export interface StructuredOutputOptions<T> extends GenerateTextOptions {
  // A short description of the JSON shape the model must return. Kept as a
  // plain string (rather than a full JSON-schema type) so any provider —
  // including ones without native structured-output support — can honor it
  // by instruction, then have the caller validate/parse.
  schemaDescription: string;
  parse: (raw: string) => T;
}

/**
 * The contract every model provider (Anthropic, OpenAI, Gemini, local, ...)
 * implements. Nothing above this layer — router, API routes, UI — is ever
 * allowed to import a provider SDK directly or branch on provider name.
 * Swapping or adding a provider means adding one file here, nothing else.
 */
export interface AIProvider {
  readonly name: string;

  generateText(options: GenerateTextOptions): Promise<GenerateTextResult>;

  streamText(
    options: GenerateTextOptions
  ): AsyncGenerator<{ text: string }, GenerateTextResult, unknown>;

  generateStructuredOutput<T>(
    options: StructuredOutputOptions<T>
  ): Promise<T>;

  // Optional capabilities — not every provider/model supports every one.
  analyzeImage?(
    imageUrl: string,
    prompt: string,
    model: string
  ): Promise<string>;

  createEmbedding?(text: string, model: string): Promise<number[]>;
}
