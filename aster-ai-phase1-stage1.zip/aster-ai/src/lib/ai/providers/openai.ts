import OpenAI from "openai";
import type { ChatMessage } from "@/types/chat";
import type {
  AIProvider,
  GenerateTextOptions,
  GenerateTextResult,
  StructuredOutputOptions,
} from "./types";

function toOpenAIMessages(messages: ChatMessage[], system?: string) {
  const base = messages.map((m) => ({
    role: m.role,
    content: m.content
      .filter((c) => c.type === "text")
      .map((c) => (c as { type: "text"; text: string }).text)
      .join("\n\n"),
  }));
  return system
    ? [{ role: "system" as const, content: system }, ...base]
    : base;
}

// Second provider, wired the same way as Anthropic, to prove the router and
// API route never need to know which one is actually answering a request.
export class OpenAIProvider implements AIProvider {
  readonly name = "openai";
  private client: OpenAI;

  constructor(apiKey: string) {
    this.client = new OpenAI({ apiKey });
  }

  async generateText(opts: GenerateTextOptions): Promise<GenerateTextResult> {
    const res = await this.client.chat.completions.create({
      model: opts.model,
      max_tokens: opts.maxTokens ?? 1024,
      temperature: opts.temperature,
      messages: toOpenAIMessages(opts.messages, opts.system),
    });

    return {
      text: res.choices[0]?.message?.content ?? "",
      usage: {
        inputTokens: res.usage?.prompt_tokens ?? 0,
        outputTokens: res.usage?.completion_tokens ?? 0,
      },
      model: opts.model,
      provider: this.name,
    };
  }

  async *streamText(
    opts: GenerateTextOptions
  ): AsyncGenerator<{ text: string }, GenerateTextResult, unknown> {
    const stream = await this.client.chat.completions.create({
      model: opts.model,
      max_tokens: opts.maxTokens ?? 1024,
      temperature: opts.temperature,
      messages: toOpenAIMessages(opts.messages, opts.system),
      stream: true,
    });

    let full = "";
    for await (const chunk of stream) {
      const delta = chunk.choices[0]?.delta?.content ?? "";
      if (delta) {
        full += delta;
        yield { text: delta };
      }
    }

    return {
      text: full,
      usage: { inputTokens: 0, outputTokens: 0 }, // OpenAI's stream omits usage by default
      model: opts.model,
      provider: this.name,
    };
  }

  async generateStructuredOutput<T>(
    opts: StructuredOutputOptions<T>
  ): Promise<T> {
    const system = [
      opts.system,
      `Respond with ONLY valid JSON matching this shape, no markdown fences, no preamble: ${opts.schemaDescription}`,
    ]
      .filter(Boolean)
      .join("\n\n");
    const result = await this.generateText({ ...opts, system });
    return opts.parse(result.text.replace(/```json|```/g, "").trim());
  }
}
